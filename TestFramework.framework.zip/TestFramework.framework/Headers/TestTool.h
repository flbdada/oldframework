//
//  TestTool.h
//  TestFramework
//
//  Created by 迟宸 on 2020/9/24.
//  Copyright © 2020 nn. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestTool : NSObject

+ (void)showTest;

@end

NS_ASSUME_NONNULL_END
